# School-Schedule

A program that replicates a school setting with a max limit on the number of classrooms
